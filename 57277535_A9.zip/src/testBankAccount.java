
public class testBankAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount b2 = new BankAccount(33000.0,6.700);
		b2.withdraw(1500);
		b2.deposit(1000);
		b2.displayInfo();
		

	}

}

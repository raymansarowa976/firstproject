
public class testCuboid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cuboid c1 = new Cuboid();
		Cuboid c2 = new Cuboid(8,3.5,5.9,"Green");
		System.out.println("Cuboid 1");
		c1.displayInfo();
		System.out.println("Cuboid 2");
		c2.displayInfo();
		
		
		

	}

}
